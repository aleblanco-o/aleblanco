---
category:
  - "[[Books]]"
author: []
cover: 
genre: []
length: 
isbn: 
isbn13: 
year: 
rating: 
topics: []
created: {{date}}
last: 
via: ""
tags:
  - books
  - references
  - to-read
---
