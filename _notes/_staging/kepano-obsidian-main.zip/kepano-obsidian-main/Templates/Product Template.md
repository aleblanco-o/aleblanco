---
category:
  - "[[Products]]"
type: 
maker: 
model: 
rating: 
price: 
acquired: {{date}}
monthly-uses: 
tags:
  - products
---
