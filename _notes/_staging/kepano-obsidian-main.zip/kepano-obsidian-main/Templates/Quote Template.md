---
attribution: []
source: 
created: {{date}}
tags:
  - quotes
topics: []
via:
---
