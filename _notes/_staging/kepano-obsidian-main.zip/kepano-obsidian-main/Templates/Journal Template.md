---
created: {{date}}
tags:
  - note
  - journal
---
