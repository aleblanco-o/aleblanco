---
category:
  - "[[Recipes]]"
cuisine: 
type: []
ingredients: 
author: []
url: 
rating: 
created: {{date}}
last: {{date}}
tags:
  - recipes
---
## Ingredients

- 

## Directions

- 

## Notes

- 