---
category:
  - "[[Movies]]"
cover: 
genre: []
director: 
cast: []
rating: 
year: 
last: {{date}}
imdbId: 
via: 
tags:
  - movies
  - references
---

[[{{date}}]]

