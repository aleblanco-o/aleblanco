---
category:
  - "[[Places]]"
type:
  - "[[Restaurants]]"
loc: 
rating: 
created: {{date}}
last: {{date}}
tags:
  - places
  - restaurants
---
## [[{{date}}]]