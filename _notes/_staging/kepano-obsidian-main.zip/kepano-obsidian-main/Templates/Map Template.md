---
tags:
  - maps
---

```leaflet
id: nyc
minZoom: 10
maxZoom: 20
defaultZoom: 12
linksTo: [[New York]]
height: 400px
coordinates: [[New York]]
```