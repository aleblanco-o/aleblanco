---
category:
  - "[[Places]]"
tags:
  - places
type:
  - "[[Shrines]]"
  - "[[Parks]]"
loc:
  - "[[Kyoto]]"
  - "[[Japan]]"
rating: 7
created: 2023-09-12
location:
  - "34.9689499"
  - "135.7692576"
---
