---
category:
  - "[[Shows]]"
genre:
  - "[[Sci-fi]]"
rating: 7
created: 2023-09-12
last: 2023-09-12
tags:
  - shows
  - references
---
