---
category:
  - "[[Movies]]"
cover: https://m.media-amazon.com/images/M/MV5BNzQzMzJhZTEtOWM4NS00MTdhLTg0YjgtMjM4MDRkZjUwZDBlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg
genre:
  - "[[Sci-fi]]"
director:
  - "[[Ridley Scott]]"
cast:
  - "[[Harrison Ford]]"
rating: 7
year: 1982
last: 2023-09-14
imdbId: tt0083658
tags:
  - movies
  - references
---


