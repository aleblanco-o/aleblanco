---
category:
  - "[[Games]]"
system: "[[Nintendo Switch]]"
maker: "[[Nintendo]]"
genre:
  - "[[Open world]]"
aliases:
  - BOTW
last: "[[2022-04]]"
rating: 7
year: 2017
tags:
  - games
  - references
---
