---
category:
  - "[[Meetings]]"
type: []
date: 2023-09-14
org:
  - "[[Obsidian]]"
loc:
  - Remote
people:
  - "[[Steph Ango]]"
topics:
  - "[[Emergence]]"
tags:
  - meetings
---
- Discussed the book [[Out of Control]] on the topic of [[Emergence]]